import { it, expect, describe } from 'vitest';

describe('group', () => {
  it('should', () => {
    expect(true).toBeTruthy();
  })
})